# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.
import glob                      # generates lists of files matching given patterns
import pdfplumber
import os
import pandas as pd
import streamlit as st
#NEW EXTRACTION OF DATA
def get_keyword(start, end, text):
    for i in range(len(start)):
        try:
            field=((text.split(start[i]))[1].split(end[i])[0])
            return field
        except:
            continue
#extracting....
def extract_content_keyword():
    my_dataframe = pd.DataFrame()
    for files in glob.glob('C:\\Users\\Majoro\\Videos\\major skul\\Leriba\\tool\\StreamlitDataExtraction-main\\invoices\\*.pdf'):
        with pdfplumber.open(files) as pdf:
            page = pdf.pages[0]
            text = page.extract_text()
            text = " ".join(text.split())
            
            start = ['COMPANY NAME: ']
            end = [' ']
            keyword1 = get_keyword(start, end, text)
            
            start = ['INVOICE NR: ']
            end = [' ']
            keyword2 = get_keyword(start, end, text)
            
            start = ['DATE: ']
            end = [' ']
            keyword3 = get_keyword(start, end, text)
            
            start = ['DUE DATE: ']
            end = [' ']
            keyword4 = get_keyword(start, end, text)
            
            start = ['09/2022 ']
            end = ['63011729168']
            keyword5 = get_keyword(start, end, text)
            
            start = ['FNB ']
            end = ['DUE DATE']
            keyword6 = get_keyword(start, end, text)
            
            
            start = ['TOTAL AMOUNT ']
            end = [' ']
            keyword7 = get_keyword(start, end, text)
            
            # create a list with the keywords extracted from current document.
            my_list = [keyword1, keyword2,keyword3,keyword4,keyword5,keyword6,keyword7]
            # append my list as a row in the dataframe.
            my_list = pd.Series(my_list)

            # append the list of keywords as a row to my dataframe.
            my_dataframe = my_dataframe.append(my_list, ignore_index=True)
            st.write("Data extracted successfully!")

            
            
    # rename dataframe columns using dictionaries.
    my_dataframe = my_dataframe.rename(columns={0:'Company Name',
                                            1:'Invoice Number',
                                            2:'Date',
                                            3:'Due Date',
                                            4:'Bank Name',
                                            5:'Account Number',
                                            6:'Total Amount'})
    save_path = ('C:\\Users\\Majoro\\Videos\\major skul\\leriba\\tool\\StreamlitDataExtraction-main\\sample_docs')
    os.chdir(save_path)    

    # extract my dataframe to an .xlsx file!
    my_dataframe.to_excel('sample_excel.xlsx', sheet_name = 'my dataframe')
    st.write("")
    st.write(my_dataframe)

 # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    extract_content_keyword()

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
